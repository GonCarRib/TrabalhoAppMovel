Trabalho computaçao movel
